package com.shifttrack.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.os.Build;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        WebView w = new WebView(this);
        w.setWebViewClient(new WebViewClient());
        w.setTag("web");

        // Keep the WebView content above Android's navigation bar, including
        // Samsung's gesture/3-button navigation area and Android 15 edge-to-edge.
        w.setOnApplyWindowInsetsListener((view, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), bottom);
            return insets;
        });
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
        w.requestApplyInsets();
    }
    @Override public void onBackPressed() {
        WebView w = (WebView)findViewById(android.R.id.content).findViewWithTag("web");
        super.onBackPressed();
    }
}
